package com.springlec.p14011.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springlec.p14011.dto.IDao;

@Controller
public class BController {
	
	//콘트롤러는 가장 먼저 보는 것이기 때문에 가장 간략하게 사용하는게 좋음, 다른 클래스를 만들어서 실행시켜 불러오는 것이 좋음 
	//커맨드가 실제로 구동되는 코드들 
	//Dto 는 하나는 꼭 있어어야 함 (데이터를 받아오는 것이기 때문)
	private static final Logger logger = LoggerFactory.getLogger(BController.class);
	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/list")
	public String list(Model model) {
		
		System.out.println("list()");
		IDao dao = sqlSession.getMapper(IDao.class);
		model.addAttribute("list", dao.listDao());
		
		return "/list";
	}
	
	@RequestMapping("/write_view")
	public String write_view() {
		System.out.println("write_view()");
		
		return "/write_view";
	}
	
	@RequestMapping("/write")
	public String write(HttpServletRequest request) {
		System.out.println("write()");
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.writeDao(request.getParameter("bName"), request.getParameter("bNumber"), request.getParameter("bAddress"), request.getParameter("bEmail"), request.getParameter("bRelationship"));
		
		return "redirect:list";
	}
	
	@RequestMapping("/content_view")
	public String content_view(HttpServletRequest request, Model model) {
		System.out.println("content_view()");
		
		IDao dao = sqlSession.getMapper(IDao.class);
		model.addAttribute("content", dao.contentDao(request.getParameter("bId")));
		// "content"는 content_view.jsp에 value 과 동일해야함 
			
		
		return "/content_view";
	}
	
	@RequestMapping("/modify")
	public String modyfy(HttpServletRequest request) {
		System.out.println("modify()");
		IDao dao = sqlSession.getMapper(IDao.class);
		
		dao.modifyDao(request.getParameter("bId"), request.getParameter("bName"), request.getParameter("bNumber"), request.getParameter("bAddress"), request.getParameter("bEmail"), request.getParameter("bRelationship"));
		
		
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request) {
		System.out.println("delete()");
		IDao dao = sqlSession.getMapper(IDao.class);
		dao.deleteDao(request.getParameter("bId"));
		
		return "redirect:list";
	}
}
