package com.springlec.p14011.dto;

import java.util.ArrayList;

import com.springlec.p14011.dto.BDto;

public interface IDao {
	public ArrayList<BDto> listDao();
	public void writeDao(String bName, String bNumber, String bAddress, String bEmail, String bRelationship);
	public BDto contentDao(String bId);
	public void modifyDao(String bId, String bName, String bNumber, String bAddress, String bEmail, String bRelationship);
	public void deleteDao(String bId);
}

