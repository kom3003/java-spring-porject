package com.springlec.p13012.command;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.springlec.p13012.dao.BDao;

public class BModifyCommand implements BCommand {

	@Override
	public void execute(Model model) {
		// TODO Auto-generated method stub
		Map<String, Object> map = model.asMap();
		HttpServletRequest request = (HttpServletRequest) map.get("request");
		
		String bId = request.getParameter("bId");
		String bName = request.getParameter("bName");
		String bNumber = request.getParameter("bNumber");
		String bAddress = request.getParameter("bAddress");
		String bEmail = request.getParameter("bEmail");
		String bRelationship = request.getParameter("bRelationship");
		
		BDao dao = new BDao();
		dao.modify(bId, bName, bNumber, bAddress, bEmail, bRelationship);
		
		
	}

}
