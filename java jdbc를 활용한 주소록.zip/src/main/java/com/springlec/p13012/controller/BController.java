package com.springlec.p13012.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springlec.p13012.util.Constant;
import com.springlec.p13012.command.BCommand;
import com.springlec.p13012.command.BContentCommand;
import com.springlec.p13012.command.BDeleteCommand;
import com.springlec.p13012.command.BListCommand;
import com.springlec.p13012.command.BModifyCommand;
import com.springlec.p13012.command.BWriteCommand;

@Controller
public class BController {
	
	//콘트롤러는 가장 먼저 보는 것이기 때문에 가장 간략하게 사용하는게 좋음, 다른 클래스를 만들어서 실행시켜 불러오는 것이 좋음 
	//커맨드가 실제로 구동되는 코드들 
	//Dto 는 하나는 꼭 있어어야 함 (데이터를 받아오는 것이기 때문)
	
	BCommand command = null;
	
	private JdbcTemplate template;
	
	@Autowired
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
		Constant.template = this.template;
	}
	
	@RequestMapping("/list")
	public String list(Model model) {
		
		System.out.println("list()");
		command	= new BListCommand();
		
		command.execute(model);
		
		
		return "list";
	}
	
	@RequestMapping("/write_view")
	public String write_view(Model model) {
		System.out.println("write_view()");
		
		return "write_view";
	}
	
	@RequestMapping("/write")
	public String write(HttpServletRequest request, Model model) {
		System.out.println("write()");
		model.addAttribute("request", request);
		command = new BWriteCommand();
		command.execute(model);
		
		return "redirect:list";
	}
	
	@RequestMapping("/content_view")
	public String content_view(HttpServletRequest request, Model model) {
		System.out.println("content_view()");
		model.addAttribute("request",request);
		command = new BContentCommand();
		command.execute(model);
		
		return "content_view";
	}
	
	@RequestMapping("/modify")
	public String modyfy(HttpServletRequest request, Model model) {
		System.out.println("modify()");
		model.addAttribute("request",request);
		command = new BModifyCommand();
		command.execute(model);
		
		return "redirect:list";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		System.out.println("delete()");
		model.addAttribute("request",request);
		command = new BDeleteCommand();
		command.execute(model);
		
		return "redirect:list";
	}
}
