package com.springlec.p13012.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.springlec.p13012.util.Constant;
import com.springlec.p13012.dto.BDto;

public class BDao {
	
	JdbcTemplate template;
	
	public BDao() {
		// TODO Auto-generated constructor stub
		this.template = Constant.template;
		
	}
	
	
	public ArrayList<BDto> list() {
		
		String query = "select bId, bName, bNumber, bAddress, bEmail, bRelationship from mvc_address";
		return (ArrayList<BDto>) template.query(query, new BeanPropertyRowMapper<BDto>(BDto.class));
		
	}
	
	public void write(final String bName, final String bNumber, final String bAddress, final String bEmail, final String bRelationship) {
		
		template.update(new PreparedStatementCreator() {
			
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				String query = "insert into mvc_address (bName, bNumber, bAddress, bEmail, bRelationship) values (?,?,?,?,?)";
				PreparedStatement preparedStatement = con.prepareStatement(query);
				preparedStatement.setString(1, bName);
				preparedStatement.setString(2, bNumber);
				preparedStatement.setString(3, bAddress);
				preparedStatement.setString(4, bEmail);
				preparedStatement.setString(5, bRelationship);
				
				return preparedStatement;
			}
		});
		
	}
	
	public BDto contentView(String strId) {
		
		String query = "select * from mvc_address where bId = " + strId;
//		return template.queryForObject(query, ParameterizedBeanPropertyRowMapper.newInstance(BDto.class));
		return template.queryForObject(query, new BeanPropertyRowMapper<BDto>(BDto.class));
		
	}
	
	
	public void modify(final String bId, final  String bName, final String bNumber, final String bAddress, final String bEmail, final String bRelationship) {

		String query = "update mvc_address set bName = ?, bNumber = ?, bAddress = ?, bEmail = ?, bRelationship = ? where bId = ?";
		
		this.template.update(query, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, bName);
				ps.setString(2, bNumber);
				ps.setString(3, bAddress);
				ps.setString(4, bEmail);
				ps.setString(5, bRelationship);
				ps.setInt(6, Integer.parseInt(bId));
			}
		});
		
	}
	
	public void delete(final String bId) {

		String query = "delete from mvc_address where bId = ?";
		
		this.template.update(query, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, bId);
			}
		});
		
		
	}
	
}
