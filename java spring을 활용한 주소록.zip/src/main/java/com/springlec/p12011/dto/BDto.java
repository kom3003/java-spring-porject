package com.springlec.p12011.dto;


public class BDto {
	
	int	bId;
	String bName;
	String bNumber;
	String bAddress;
	String bEmail;
	String bRelationship;
	
	public BDto(int bId, String bName, String bNumber, String bAddress, String bEmail, String bRelationship) {
		super();
		this.bId = bId;
		this.bName = bName;
		this.bNumber = bNumber;
		this.bAddress = bAddress;
		this.bEmail = bEmail;
		this.bRelationship = bRelationship;
	}

	public int getbId() {
		return bId;
	}

	public void setbId(int bId) {
		this.bId = bId;
	}

	public String getbName() {
		return bName;
	}

	public void setbName(String bName) {
		this.bName = bName;
	}

	public String getbNumber() {
		return bNumber;
	}

	public void setbNumber(String bNumber) {
		this.bNumber = bNumber;
	}

	public String getbAddress() {
		return bAddress;
	}

	public void setbAddress(String bAddress) {
		this.bAddress = bAddress;
	}

	public String getbEmail() {
		return bEmail;
	}

	public void setbEmail(String bEmail) {
		this.bEmail = bEmail;
	}

	public String getbRelationship() {
		return bRelationship;
	}

	public void setbRelationship(String bRelationship) {
		this.bRelationship = bRelationship;
	}
	
	
	
}
