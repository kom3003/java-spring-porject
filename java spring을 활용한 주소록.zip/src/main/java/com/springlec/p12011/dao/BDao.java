package com.springlec.p12011.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.sql.DataSource;

import com.springlec.p12011.dto.BDto;

import javax.naming.Context;
import javax.naming.InitialContext;

public class BDao {
	
	DataSource dataSource;
	
	public BDao() {
		// TODO Auto-generated constructor stub
		
		try {
			
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/mvc");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public ArrayList<BDto> list() {
	
		ArrayList<BDto>	dtos = new ArrayList<BDto>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			
			connection = dataSource.getConnection();
			
			String query = "select bId, bName, bNumber, bAddress, bEmail, bRelationship from mvc_address";
			preparedStatement = connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				int	bId	= resultSet.getInt("bId");
				String bName= resultSet.getString("bName");
				String bNumber= resultSet.getString("bNumber");
				String bAddress= resultSet.getString("bAddress");
				String bEmail= resultSet.getString("bEmail");
				String bRelationship = resultSet.getString("bRelationship");
				
				BDto dto = new BDto(bId, bName, bNumber, bAddress, bEmail, bRelationship);
				dtos.add(dto);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				
				if(resultSet!=null) {
					resultSet.close();
				}
				if(preparedStatement!=null) {
					preparedStatement.close();
				}
				if(connection!=null) {
					connection.close();
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		return dtos;
	}
	
	public void write(String bName, String bNumber, String bAddress, String bEmail, String bRelationship) {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		
		try {
			
			connection = dataSource.getConnection();
			
			String	query = "insert into mvc_address(bName, bNumber, bAddress, bEmail, bRelationship) values(?, ?, ?, ?, ?)";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, bName);
			preparedStatement.setString(2, bNumber);
			preparedStatement.setString(3, bAddress);
			preparedStatement.setString(4, bEmail);
			preparedStatement.setString(5, bRelationship);
			
			preparedStatement.executeUpdate();
			
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				
				if(preparedStatement!=null) {
					preparedStatement.close();
				}
				if(connection!=null) {
					connection.close();
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
	}
	
	public BDto contentView(String strId) {
		BDto dto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			
			connection = dataSource.getConnection();
			
			String query = "select * from mvc_address where bId = ?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(strId));
			
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				
				// resultset 으로 부르는 것은 mysql 컬럼에 이름을 써야 함 그래야 데이터를 가져옴 
				
				int	bId	= resultSet.getInt("bId");
				String bName= resultSet.getString("bName");
				String bNumber= resultSet.getString("bNumber");
				String bAddress= resultSet.getString("bAddress");
				String bEmail = resultSet.getString("bEmail");
				String bRelationship = resultSet.getString("bRelationship");
				
				dto = new BDto(bId, bName, bNumber, bAddress, bEmail, bRelationship);
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				
				if(resultSet!=null) {
					resultSet.close();
				}
				if(preparedStatement!=null) {
					preparedStatement.close();
				}
				if(connection!=null) {
					connection.close();
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		return dto;
		
	}
	
	public void modify(String bId, String bName, String bNumber, String bAddress, String bEmail, String bRelationship) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			
			connection = dataSource.getConnection();
			
			String query = "update mvc_address set bName = ?, bNumber = ?, bAddress = ?, bEmail = ?, bRelationship = ? where bId = ?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, bName);
			preparedStatement.setString(2, bNumber);
			preparedStatement.setString(3, bAddress);
			preparedStatement.setString(4, bEmail);
			preparedStatement.setString(5, bRelationship);
			preparedStatement.setInt(6, Integer.parseInt(bId));
			
			preparedStatement.executeUpdate();
			
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				
				if(preparedStatement!=null) {
					preparedStatement.close();
				}
				if(connection!=null) {
					connection.close();
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		
	}
	
	public void delete(String bId) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			
			connection = dataSource.getConnection();
			
			String query = "delete from mvc_address where bId = ?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(bId));
			
			preparedStatement.executeUpdate();
			
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				
				if(preparedStatement!=null) {
					preparedStatement.close();
				}
				if(connection!=null) {
					connection.close();
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		
	}
	
}
