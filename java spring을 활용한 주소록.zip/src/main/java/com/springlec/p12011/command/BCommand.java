package com.springlec.p12011.command;

import org.springframework.ui.Model;

public interface BCommand {

	void execute(Model model);
	
	//인터페이스 메소드 이름을 정할 수 있지만 내용을 정할 수 없
	
	
	
}
